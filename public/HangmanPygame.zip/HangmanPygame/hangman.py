import math
import random
import pygame

pygame.init()
#Window
width = 1000
height = 750

window = pygame.display.set_mode((width, height))
pygame.display.set_caption("Hangme")


#Image loop
images = []
for i in range(1, 9):
    image = pygame.image.load("HangMeGraphics\HangMe"+str(i)+".png")
    images.append(image)

print(images)

#Button variables
radius = 30
gap = 13
letters = []
startx = round((width - (radius * 2 + gap) * 13)/2)
starty = 600
startChar = 65
for i in range(26):
    x = startx + gap * 2 + ((radius * 2 + gap) * (i % 13))
    y = starty + ((i // 13)*(gap + radius * 2))
    letters.append([x, y, chr(startChar + i), True])


#Colors
White = (255, 255, 255)
Black = (0, 0, 0)
Red = (255, 0, 0)
Blue = (0, 0, 255)
Green = (0, 255, 0)


#Fonts
letterFont = pygame.font.SysFont("comicsans", 40)
wordFont = pygame.font.SysFont("comicsans", 70)

#Game loop
FPS = 60
clock = pygame.time.Clock()
run = True


def draw():
    window.fill(White)

    #Draw word
    displayWord = ""
    for letter in word:
        if letter in guessed:
            displayWord += letter + " "
        else:
            displayWord += "_ "
    text = wordFont.render(displayWord, 1, Black)
    window.blit(text, (width/3, 435))

    #Draw letters
    for letter in letters:
        x, y, ltr, visible = letter
        if visible:
            pygame.draw.circle(window, Black, (x, y), radius, 3)
            text = letterFont.render(ltr, 1, Black)
            window.blit(text, (x - text.get_width()/2, y - text.get_height()/2))

    window.blit(images[status], (-60, -30))
    pygame.display.update()


def displayMessage(message, tcolor, bgcolor):
    pygame.time.delay(1000)
    window.fill(bgcolor)
    text = wordFont.render(message, 1, tcolor)
    window.blit(text, (width/2 - text.get_width()/2, height/2 - text.get_height()/2))
    pygame.display.update()
    pygame.time.delay(1500)



def main():
    global status
    global run
    while run:
        clock.tick(FPS)

        draw()
        won = True
        for letter in word:
            if letter not in guessed:
                won = False
                break
        if won:
            displayMessage("You won!", Green, Blue)
            break

        if status == 7:
            displayMessage("You lost!", Red, Black)
            displayMessage(f"Word was: {word}", Blue, White)
            break

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouseX, mouseY = pygame.mouse.get_pos()
                for letter in letters:
                    x, y, ltr, visible = letter
                    if visible:
                        dis = math.sqrt((x-mouseX)**2 + (y - mouseY)**2)
                        if dis < radius:
                            letter[3] = False
                            guessed.append(ltr)
                            if ltr not in word:
                                status += 1

def mainMenu():
    displayMessage("Play  |  Stop", Blue, Black)
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            print(pos)
            if (200, 200) < pos < (450, 700):
                main()
            elif (500, 200) < pos < (900, 700):
                pygame.QUIT
                exit()
            else:
                mainMenu() 
                            
    
    
def remove_newlines(fname):
    flist = open(fname).readlines()
    return [s.rstrip('\n') for s in flist]

while True:
    for i in letters:
        i[3] = True
    #Game variables
    status = 0
    words = remove_newlines("words.txt")
    word = random.choice(words)
    word = word.upper()
    guessed = []
    mainMenu()